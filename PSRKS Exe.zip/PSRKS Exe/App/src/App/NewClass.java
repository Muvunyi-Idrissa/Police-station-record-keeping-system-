/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;




/**
 *
 * @author MUVUNYI Iddi
 */
public class NewClass {
    
    public static int Id;
    public static String name;
    public static String names;
    public static String state;
    public static String emplnames;
    public static String accnumbers;
    public static double balance;
    public static String phoneno;
    public static String ids;
    public static String owners;
    public static int transId;
    public static int nid;
    public static String officer;
    public static String doc;
    
    
    
    
   
    
    
     
    
   
     
     
     
    
    
}


